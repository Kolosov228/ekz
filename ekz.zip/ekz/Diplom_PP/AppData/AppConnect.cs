﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diplom_PP.AppData
{
    class AppConnect
    {
        public static DiplomEntities model1db;
    }
}
